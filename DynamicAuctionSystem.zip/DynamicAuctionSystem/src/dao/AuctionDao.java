package dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import bean.AuctionBean;
import util.DBConnection;

public class AuctionDao {
	Connection c=null;
	public  AuctionDao() throws ClassNotFoundException, SQLException
	{
		DBConnection dbu =new DBConnection();
		c=dbu.getDBConn();
	}
	 public void Userinsert(AuctionBean ab) 
	  {
		  try
		  {
		  PreparedStatement p=c.prepareStatement("insert into user_xbbnhhx(first_name,last_name,gender,address,country,state,city,email,contact,password,login_type)values(?,?,?,?,?,?,?,?,?,?,?)");
		  p.setString(1,ab.getThname());
		  p.setString(2,ab.getThadr());
		  p.execute();
		  }
		  catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	  }
	 public void filmdet(AuctionBean ab)
	 {
		 try
		  {
		  PreparedStatement p=c.prepareStatement("insert into Film(fid,fname,fcert)values(fid.nextval,?,?)");
		  p.setString(1,tkt.getFname());
		  p.setString(2,tkt.getFcert());
		  p.execute();
		  }
		  catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 }
	 public void showdet(AuctionBean ab,int id,int idd)
	 {
		 try
		  {
		  //System.out.println("dcgh");	 
		  PreparedStatement p=c.prepareStatement("insert into Show(thid,fid,shid,shdate,shtime,sno1,sno2,sno3,sno4,sno5,sno6,sno7,sno8,sno9,sno10,shprice)values(?,?,shid.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		  Date d=new Date();
	      SimpleDateFormat sdf=new SimpleDateFormat("dd-mm-yyyy");
		  p.setInt(1,id);
		  p.setInt(2,idd );
		  d=sdf.parse(tkt.getShdate());
		  p.setDate(3, new java.sql.Date(d.getTime()));
		  p.setString(4,tkt.getShtime());
		  p.setString(5,tkt.getSno1());
		  p.setString(6,tkt.getSno2());
		  p.setString(7,tkt.getSno3());
		  p.setString(8,tkt.getSno4());
		  p.setString(9,tkt.getSno5());
		  p.setString(10,tkt.getSno6());
		  p.setString(11,tkt.getSno7());
		  p.setString(12,tkt.getSno8());
		  p.setString(13,tkt.getSno9());
		  p.setString(14,tkt.getSno10());
		  p.setDouble(15,tkt.getShprice());
		  p.execute();
		  }
		  catch (SQLException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 }
	 public void userinsert(AuctionBean ab)
	 {
		 try
		  {
		  PreparedStatement p=c.prepareStatement("insert into Userdt(usid,uname,uaddr,upass,ugender,uphno)values(usid.nextval,?,?,?,?,?)");
		  p.setString(1,tkt.getUname());
		  p.setString(2,tkt.getUaddr());
		  p.setString(3,tkt.getUpass());
		  p.setString(4,tkt.getUgender());
		  p.setLong(5,tkt.getUphno());
		  p.execute();
		  }
		  catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 }
	 
	 public int  bookinginsert(AuctionBean ab,int fdid,int tid,int uuid)
	 {
		 try
		  {
		  PreparedStatement p=c.prepareStatement("insert into Bookingdet(fid,thid,bdate,btime,usid,nost)values(?,?,?,?,?,?)");
		  p.setInt(1,fdid);
		  p.setInt(2,tid);
		  Date d=new Date();
	      SimpleDateFormat sdf=new SimpleDateFormat("dd-mm-yyyy");
	      d=sdf.parse(tkt.getBdate());
		  p.setDate(3, new java.sql.Date(d.getTime()));
		  p.setString(4,tkt.getBtime());
		  p.setInt(5,uuid);
		  p.setString(6,tkt.getNost());
		  p.execute();
		  }
		  catch (SQLException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return 0; 
	 }
	 public void display() 
	 {
		 PreparedStatement p;
		try {
			p = c.prepareStatement("select thname,thadr from theatre");
			ResultSet rs=p.executeQuery("select thname,thadr from theatre");
			 while(rs.next())
			 {
				System.out.println(rs.getString(1)+" "+rs.getString(2));
			 }
			 display2();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	 }
	private void display2() {
		// TODO Auto-generated method stub
		PreparedStatement p;
		try {
			p = c.prepareStatement("select fname,fcert from Film");
			ResultSet rs=p.executeQuery("select fname,fcert from Film");
			 while(rs.next())
			 {
				System.out.println(rs.getString(1)+" "+rs.getString(2));
			 }
			display3(); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private void display3() {
		// TODO Auto-generated method stub
		PreparedStatement p;
		try {
			p = c.prepareStatement("select shdate,shtime,sno1,sno2,sno3,sno4,sno5,sno6,sno7,sno8,sno9,sno10,shprice from Show");
			ResultSet rs=p.executeQuery("select shdate,shtime,sno1,sno2,sno3,sno4,sno5,sno6,sno7,sno8,sno9,sno10,shprice from Show");
			 while(rs.next())
			 {
				System.out.println(rs.getDate(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6)+" "+rs.getString(7)+" "+rs.getString(8)+" "+rs.getString(9)+" "+rs.getString(10)+" "+rs.getString(11)+" "+rs.getString(12)+" "+rs.getDouble(13));
			 }
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
