package bean;

public class AuctionBean {
	//user 
private String	user_name;
private String	first_name;
private	String last_name;
private	String gender;
private	String address;
private	String country;
private	String state;
private	String city;
private	String email;
private	int contact;
private	String password;
private String	login_type;



//product
private String  product_id;
private String category_id;
//private String	user_name;
private String product_name;
private String product_description;
private int min_bid_price;
private String status;
private String photo;
private int start_date;
private int end_date;


//country

private String country_id;
private String country_name;



}